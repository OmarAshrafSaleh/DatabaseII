import java.io.*;
import java.util.ArrayList;


public class Page implements Serializable{
	
	public static int pageNum=0;
	public String URL = "";
	
	ArrayList<ArrayList<Object>> record = new ArrayList<ArrayList<Object>>();

	
	public Page(String TableName) {
		
		String Path =  "C:\\Users\\omara\\Desktop\\"+TableName;
				this.URL = "C:\\Users\\omara\\Desktop\\"+TableName+"\\page"+pageNum+".class";
				
				File page = new File("C:\\Users\\omara\\Desktop\\"+TableName,"page"+pageNum+".class");
				pageNum ++;
				this.Serialize(URL);
	}
	
//*********srlization Code************	
//	try {
//        FileOutputStream fileOut = new FileOutputStream("C:\\Users\\omara\\Desktop\\"+TableName+"\\"+"Page.class");
//        ObjectOutputStream out = new ObjectOutputStream(fileOut);
//        out.writeObject(this);
//        out.close();
//        fileOut.close();
//        System.out.printf("Serialized data is saved in /tmp/employee.ser");
//     } catch (IOException i) {
//        i.printStackTrace();
//     }
	
  
	
	public void Serialize (String path) {
		try {
	        FileOutputStream fileOut = new FileOutputStream(URL);
	        ObjectOutputStream out = new ObjectOutputStream(fileOut);
	        out.writeObject(this);
	        out.close();
	        fileOut.close();
	        System.out.println("Serialized");
	     } catch (IOException i) {
	        i.printStackTrace();
	     }
	}
	
	}

	
