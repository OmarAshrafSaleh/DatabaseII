import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

		public class DBApp2 {
		  public static void main(String[] args) {

			Properties prop = new Properties();
			OutputStream output = null;

			try {

				output = new FileOutputStream("DBApp.config.properties");

				// set the properties value
				prop.setProperty("MaximumRowsCountinPage", "200");
				prop.setProperty("BRINSize", "15");
				
				// save properties to project root folder
				prop.store(output, null);

			} catch (IOException io) {
				io.printStackTrace();
			} finally {
				if (output != null) {
					try {
						output.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

			}
		  }
		}
		
		
