import java.io.*;
import java.security.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;

import com.sun.prism.impl.Disposer.Record;

public class DBApp {
	public static ArrayList<String> Tables = new ArrayList<String>();

	public static void createTable(String strTableName,
			String strClusteringKeyColumn,
			Hashtable<String, String> htblColNameType) throws DBAppException,
			IOException {

		String path = "C:\\Users\\ahmed\\Desktop";
		String TableURL = path + "\\" + strTableName;

		Tables.add(TableURL);
		File table = new File(path, strTableName);
		if (!(table.exists())) {
			System.out.println("Creating directory" + table.getName());
			boolean result = false;
			try {
				table.mkdir();
				result = true;
			} catch (SecurityException se) {

			}
			if (result) {
				System.out.println("Directory created");
			}
		} else {
			System.out.println("Table name already exsist");
		}
		String[] CoulmnName = new String[htblColNameType.size()];
		htblColNameType.keySet().toArray(CoulmnName);
		File metadata = new File("C:\\Users\\ahmed\\workspace\\m4\\Dmet\\DBII.1", "metadata.csv");
		BufferedWriter writer = new BufferedWriter(new FileWriter(metadata));
		for (int i = 0; i < htblColNameType.size(); i++) {
			String key = "false";
			if (CoulmnName[i].equals(strClusteringKeyColumn))
				key = "true";
			String line = strTableName + "," + CoulmnName[i] + ","
					+ htblColNameType.get(CoulmnName[i]) + "," + key;
			writer.write(line);
			writer.newLine();

		}
		writer.close();

		Page page1 = new Page(strTableName);
		Page p = Deserialize("C:\\Users\\ahmed\\Desktop\\" + strTableName
				+ "\\page0.class");

		String[] v = new String[htblColNameType.size()];
		Collection<String> Value = htblColNameType.values();
		Value.toArray(v);
		for (int i = 0; i < v.length; i++) {
			p.Types.add(v[i]);

			// ********************TEST*********************

			System.out.print(p.Types.get(i) + ",");
		}

		Set<String> e = htblColNameType.keySet();
		String[] t = new String[e.size()];
		e.toArray(t);
		for (int i = 0; i < t.length; i++) {
			if (t[i].equals(strClusteringKeyColumn))
				p.KeyLocation = i;

			// ********************TEST*********************

			System.out.println(t[i] + ",");
			System.out.println("" + p.KeyLocation + ",");

		}

	}

	public static Page Deserialize(String Path) {
		try {

			FileInputStream fileIn = new FileInputStream(Path);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			Page p = (Page) in.readObject();
			in.close();
			fileIn.close();
			return p;

		} catch (IOException i) {
			i.printStackTrace();

		} catch (ClassNotFoundException c) {
			System.out.println("Employee class not found");
			c.printStackTrace();

		}
		return null;
	}
	

	public static void insertIntoTable(String strTableName,
			Hashtable<String, Object> htblColNameValue) throws DBAppException {
		boolean flag = false;
		Object[] v = new Object[htblColNameValue.size()];
		Collection<Object> Value = htblColNameValue.values();
		Value.toArray(v);
		ArrayList<Object> values = new ArrayList();
		for (int s = 0; s < v.length; s++) {
			values.add(v[s]);
		}
		LocalDateTime l = LocalDateTime.now();
		values.add(l);
		String PageURL = "C:\\Users\\ahmed\\Desktop\\" + strTableName;
		Boolean f = false;
		for (int h = 0; h < Tables.size(); h++) {
			if (Tables.get(h).equals(
					"C:\\Users\\ahmed\\Desktop\\" + strTableName)) {
				f = true;
			}
		}
		if (f == false) {
			throw new DBAppException("The table is not found");
		}
		int numOfPages = 0;
		String page = "C:\\Users\\ahmed\\Desktop\\" + strTableName +"\\"+"page" + 0
				+ ".class";
		Page Temp = Deserialize(page);
		Set<String> e = htblColNameValue.keySet();
		String[] t = new String[e.size()];
		e.toArray(t);
//		for (int i = 0; i < t.length; i++) {
//			if (!(htblColNameValue.get(t[i]).getClass().getName()
//					.equals(Temp.Types.get(i)))) {
//				System.out.println((htblColNameValue.get(t[i]).getClass()
//						.getName()));
//				System.out.println(Temp.Types.get(i));
//				System.out.println("Fuck" + i);
//				throw new DBAppException(
//						"Input does not match column's type !!");
//			}
//		}
		for (final File file : new File(PageURL).listFiles()) {
			numOfPages++;
		}
		numOfPages = numOfPages - 1;
		for (int k = 0; k < numOfPages+1; k++) {
			String page2 = "C:\\Users\\ahmed\\Desktop\\" + strTableName
					+ "\\page" + k + ".class";
			Page des = Deserialize(page2);
			// Boolean f2 = true ;
			for (int j = 0; j < des.record.size(); j++) {

				if (t[des.KeyLocation].equals(des.record.get(j).get(
						des.KeyLocation)))
					throw new DBAppException("duplicate occurs");
			}

		}

		String page3 = "C:\\Users\\ahmed\\Desktop\\" + strTableName + "\\page"
				+ 0 + ".class";
		Page des = Deserialize(page3);

		String page4 = "C:\\Users\\ahmed\\Desktop\\" + strTableName + "\\page"
				+ numOfPages + ".class";
		Page des1 = Deserialize(page4);
		if (des.record.size() == 0) {
			des.record.add(values);
			des.Serialize(page3);
			return;
		}
		if ((int) des1.record.get(des1.record.size() - 1).get(des1.KeyLocation) < (int) values
				.get(des1.KeyLocation)) {
			if (des1.record.size() == 200) {
				Page newPage = new Page(strTableName);
				numOfPages = numOfPages + 1;
				Page newPage2 = Deserialize("C:\\Users\\ahmed\\Desktop\\"
						+ strTableName + "\\page" + numOfPages+ ".class");
				newPage2.record.add(values);
				newPage2.Serialize("C:\\Users\\ahmed\\Desktop\\" + strTableName
						+ "\\page" +numOfPages + ".class");
				return;
			} else {
				des1.record.add(values);
				des1.Serialize(page4);
				return;
			}
		} else {
			for (int i = 0; i < numOfPages+1; i++) {
				String page5 = "C:\\Users\\ahmed\\Desktop\\" + strTableName
						+ "\\page" + i + ".class";
				Page des3 = Deserialize(page5);
				for (int j = 0; j < des3.record.size(); j++) {
					if ((int) values.get(des3.KeyLocation) < (int) des3.record
							.get(j).get(des3.KeyLocation)) {
						des3.record.add(j, values);
						
						if (des3.record.size() > 200) {
							for (int h = i; h < numOfPages+1; h++) {
								if (i == numOfPages ) {

									String page6 = "C:\\Users\\ahmed\\Desktop\\"
											+ strTableName
											+ "\\page"
											+ h
											+ ".class";
									Page des4 = Deserialize(page6);
									if (des4.record.size() > 200) {
										numOfPages=numOfPages+1;
										Page newPage2 = new Page(strTableName);
										Page np = Deserialize("C:\\Users\\ahmed\\Desktop\\"
												+ strTableName
												+ "\\page"
												+ numOfPages
												+ ".class");
										np.record.add(des4.record
												.get(des4.record.size() - 1));
										np.Serialize(("C:\\Users\\ahmed\\Desktop\\"
												+ strTableName + "\\page" + numOfPages + ".class"));
										des4.Serialize(page6);
										return;
									}

								} else {
									String page6 = "C:\\Users\\ahmed\\Desktop\\"
											+ strTableName
											+ "\\page"
											+ h
											+ ".class";

									Page des4 = Deserialize(page6);
									int h2 = h + 1;
									String page7 = "C:\\Users\\ahmed\\Desktop\\"
											+ strTableName
											+ "\\page"
											+ h2
											+ ".class";
									Page des5 = Deserialize(page7);
									des5.record.add(0, des4.record
											.get(des4.record.size() - 1));
									des4.Serialize(page6);
									des5.Serialize(page7);
									return;
								}
							}
						}
						else {
							des3.Serialize(page5);
							return ;
						}
					}
				}

			}
		}

	}
	
	public static void dis (String p ){
		int  numOfPages = 0 ;
		for (final File file : new File("C:\\Users\\ahmed\\Desktop\\" + p ).listFiles()) {
			numOfPages++;
		}
		System.out.println(numOfPages);
		for (int i = 0 ; i <numOfPages ; i ++){
			String page = "C:\\Users\\ahmed\\Desktop\\" + p +"\\"+"page" + i
					+ ".class";
			Page des = Deserialize(page);
			for(int j = 0 ; j<des.record.size();j++){
				
				for(int k =0 ; k < des.record.get(j).size();k++){
					System.out.print(des.record.get(j).get(k)+ " , ");
				}
			}
		}
	}
	

	public static void deleteFromTable(String strTableName,Hashtable<String,Object> htblColNameValue)throws DBAppException{
		int loc =0;
		boolean foundRec=false;
		boolean foundTable = false ;
		String TableURL ="";
		int numOfPages =0;
		ArrayList<Object> RecordToDelete =new ArrayList<Object>();
		ArrayList<Object> ToCheck =new ArrayList<Object>();

		Object[] v = new Object[htblColNameValue.size()];
		Collection<Object> Value = htblColNameValue.values();
		Value.toArray(v);
		for(int i = 0 ; i<v.length;i++){
			RecordToDelete.add(v[i]);
			System.out.print(v[i]+" , ");
		}
		
		
		
		//Getting the table
		for (int h = 0; h < Tables.size(); h++) {
			if (Tables.get(h).equals("C:\\Users\\ahmed\\Desktop\\" + strTableName)) {
				foundTable = true;
				TableURL = "C:\\Users\\ahmed\\Desktop\\" + strTableName;
			}
		}
		if (foundTable == false) {
			throw new DBAppException("The table is not found");
		}
		
		//Getting the pages
		
		for (final File file : new File(TableURL).listFiles()) {
			numOfPages++;
		}

		for (int p = 0; p < numOfPages; p++) {
			
			String CurrentPageURL = TableURL + "\\page" + p + ".class";
			Page CurrentPage = Deserialize(CurrentPageURL);
			
			// searching for the record to delete ;
			for (int r = 0; r < CurrentPage.record.size(); r++) {
				for(int i=0;i<CurrentPage.record.get(r).size()-1;i++){
				ToCheck.add(CurrentPage.record.get(r).get(i));
				System.out.println("");
				System.out.print(ToCheck.get(i));
				System.out.print(RecordToDelete.get(i));
				
				}
				System.out.println("r ="+r+" record.size is"+CurrentPage.record.size());
				System.out.println("checking..");
				if(ToCheck.equals(RecordToDelete)){
					foundRec=true;
					loc =r;
					System.out.println("found");
					}
				ToCheck.clear();
				}
			// Deletion cases :
				if(foundRec){
					//case1 Last page (Simple remove)}
					if(p == numOfPages-1){
						CurrentPage.record.remove(loc);
						CurrentPage.Serialize(CurrentPageURL);

								
						}
					
					//case2 Deleting from any other page
					else{
						System.out.println("ok");
						CurrentPage.record.remove(loc);
						//Shifting records up
						for(int z =p;z<numOfPages;z++){
							int nxt = z+1;
							Page NxtPage = Deserialize(TableURL + "\\page"+nxt+".class");
							Page Current = Deserialize(TableURL + "\\page"+z+".class");
							ArrayList<Object> Temp = NxtPage.record.get(0);
							Current.record.add(Temp);
							NxtPage.record.remove(0);
							NxtPage.Serialize(TableURL + "\\page"+nxt+".class");
							Current.Serialize(TableURL + "\\page"+nxt+".class");
						}
						
					}
				
					//Removing empty pages only if there is more than one page
					if(numOfPages>1){
					int last = numOfPages -1;
					Page LastPage =Deserialize(TableURL + "\\page" + last + ".class");
					if(LastPage.record.size()==0){
						File EmptyPage = new File(TableURL + "\\page" + last + ".class");
						EmptyPage.delete();
					}
				}
				}
				
			}

			

			
		if(!foundRec) 
			throw new DBAppException("Record Not 1Found");
		}
		
		
	
	public static void updateTable(String strTableName,String strKey,Hashtable<String,Object> htblColNameValue )throws DBAppException{
		
		boolean foundRec = false;
		boolean foundTable = false;
		String TableURL ="";
		int numOfPages =0;
		
		
		Set<String> e = htblColNameValue.keySet();
		
		String[] t = new String[e.size()];
		e.toArray(t);
		int index=0;
		for(int i=0;i<t.length;i++)
		{
			
			if(t[i].equals(strKey))
			{
				index=i;
			}
		}
		for(int i=0;i<t.length;i++){
			System.out.println(t[i]);
		}
		
		
		
		ArrayList<Object> RecordToUpdate =new ArrayList<Object>();
		Object[] v = new Object[htblColNameValue.size()];
		Collection<Object> Value = htblColNameValue.values();
		Value.toArray(v);
		
		
		

		for(int i = 0 ; i<v.length;i++){
			RecordToUpdate.add(v[i]);
			
			}
		System.out.println(RecordToUpdate);
		
		
		
		Object o = RecordToUpdate.get(index);
		
		for (int h = 0; h < Tables.size(); h++) {
			if (Tables.get(h).equals("C:\\Users\\ahmed\\Desktop\\" + strTableName)) {
				foundTable = true;
				TableURL = "C:\\Users\\ahmed\\Desktop\\" + strTableName;
			}
		}
		if (foundTable == false) {
			throw new DBAppException("The table is not found");
		}
		
		//Getting the pages
		
		for (final File file : new File(TableURL).listFiles()) {
			numOfPages++;
		}

		for (int p = 0; p < numOfPages; p++) {
			
			String CurrentPageURL = TableURL + "\\page" + p + ".class";
			Page CurrentPage = Deserialize(CurrentPageURL);
			
			// searching for the record to update ;
			for (int r = 0; r < CurrentPage.record.size(); r++) {
				if(CurrentPage.record.get(r).get(index).equals(o)){
					CurrentPage.record.set(r,RecordToUpdate);
					foundRec =true;
					System.out.println(CurrentPage.record.get(r));
					CurrentPage.Serialize(CurrentPageURL);
					break;
					
				}

			
			}
			if(!foundRec)
				throw new DBAppException("Record not found");
			}
		
	}
	

	public static void main(String[] args) throws DBAppException, IOException {
		String strTableName = "StudentS";
		Hashtable htblColNameType = new Hashtable();
		htblColNameType.put("id", "java.lang.Integer");
		htblColNameType.put("name", "java.lang.String");
		htblColNameType.put("gpa", "java.lang.double");
		createTable(strTableName, "id", htblColNameType);
		

		Hashtable htblColNameValue = new Hashtable( );
		htblColNameValue.put("id", new Integer( 2343432 ));
		htblColNameValue.put("name", new String("Ahmed Noor" ) );
		htblColNameValue.put("gpa", new Double( 0.95 ) );
		insertIntoTable( strTableName , htblColNameValue );
		htblColNameValue.clear( );
		htblColNameValue.put("id", new Integer( 453455 ));
		htblColNameValue.put("name", new String("Ahmed Noor" ) );
		htblColNameValue.put("gpa", new Double( 0.95 ) );
		insertIntoTable( strTableName , htblColNameValue );
		htblColNameValue.clear( );
		
		htblColNameValue.put("id", new Integer( 5674567 ));
		htblColNameValue.put("name", new String("Dalia Noor" ) );
		htblColNameValue.put("gpa", new Double( 1.25 ) );
		insertIntoTable( strTableName , htblColNameValue );
		htblColNameValue.clear( );
		htblColNameValue.put("id", new Integer( 23498 ));
		htblColNameValue.put("name", new String("John Noor" ) );
		htblColNameValue.put("gpa", new Double( 1.5 ) );
		insertIntoTable( strTableName , htblColNameValue );
		htblColNameValue.clear( );
		htblColNameValue.put("id", new Integer( 78452 ));
		htblColNameValue.put("name", new String("Zaky Noor" ) );
		htblColNameValue.put("gpa", new Double( 0.88 ) );
		insertIntoTable( strTableName , htblColNameValue );
		
		

		Hashtable htblColNameValue2 = new Hashtable( );
		htblColNameValue2.put("id", new Integer( 23498 ));
		htblColNameValue2.put("name", new String("John Noor" ) );
		htblColNameValue2.put("gpa", new Double( 1.7 ) );
		
		updateTable(strTableName,"id",htblColNameValue2 );
		
		
		
	//	System.out.println(Tables.get(0));
		dis(strTableName);
	}

}
		
		
		