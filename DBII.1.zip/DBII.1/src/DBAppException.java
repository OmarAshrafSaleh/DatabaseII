
public class DBAppException extends Exception {
	public DBAppException(String msg){
		super(msg);
	}

}
