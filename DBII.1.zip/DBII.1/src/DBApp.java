import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;


public class DBApp {
public static ArrayList<String> Tables = new ArrayList<String>();

public static void createTable(String strTableName,String strClusteringKeyColumn,Hashtable<String,String> htblColNameType )throws DBAppException, IOException{
	
	Table x = new Table(strTableName);
	
	
	
	String path = "C:\\Users\\omara\\Desktop";
	String TableURL =path+"\\"+strTableName;
	Tables.add(TableURL);
	File table = new File(path,strTableName);
	if (!(table.exists())){
		System.out.println("Creating directory" + table.getName());
		boolean result = false;
		try{
			table.mkdir();
			result=true;
		}
		catch(SecurityException se) {
			
		}
		if (result){
			System.out.println("Directory created");
		}
	}
	else {
		System.out.println("Table name already exsist");
	}
	String[] CoulmnName = new String[htblColNameType.size()];
	htblColNameType.keySet().toArray(CoulmnName);
	File metadata = new File(TableURL,"metadata.txt");
	BufferedWriter writer = new BufferedWriter(new FileWriter(metadata));
	for(int i=0;i<htblColNameType.size();i++){
		String key ="false";
		if(CoulmnName[i].equals(strClusteringKeyColumn))
		key ="true";
		String line = strTableName+","+CoulmnName[i]+","+htblColNameType.get(CoulmnName[i])+","+key;
		writer.write(line);
		writer.newLine();
		
	}
	writer.close();
	
}
	public void insertIntoTable(String strTableName,Hashtable<String,Object> htblColNameValue)throws DBAppException{
		
		
				}
	
public static void main(String[] args) throws DBAppException, IOException {
	String strTableName = "StudentSS";
	Hashtable htblColNameType = new Hashtable( );
	htblColNameType.put("id", "java.lang.Integer");
	htblColNameType.put("name", "java.lang.String");
	htblColNameType.put("gpa", "java.lang.double");
	createTable( strTableName, "id", htblColNameType );
}


}
