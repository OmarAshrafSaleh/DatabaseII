import java.io.*;
import java.util.ArrayList;


public class Table {

	static int KeyLocation;
	String name ;

	//static ArrayList<ArrayList> rows = new ArrayList<ArrayList> ;
	
	
	public Table (String name) throws IOException{
		
		this.name =name;
		Page p = new Page(name);
	
		
		
		
//		*************Desrializtion Code*******************
//	    try {
//	         FileInputStream fileIn = new FileInputStream("/tmp/employee.ser");
//	         ObjectInputStream in = new ObjectInputStream(fileIn);
//	         e = (Employee) in.readObject();
//	         in.close();
//	         fileIn.close();
//	      } catch (IOException i) {
//	         i.printStackTrace();
//	         return;
//	      } catch (ClassNotFoundException c) {
//	         System.out.println("Employee class not found");
//	         c.printStackTrace();
//	         return;
//	      }
//
		

		
		
//		newFile = ""+name ;
//		boolean file = new File(newFile).mkdirs();
//		pages = new ArrayList<String>();
//		Page  p= new Page (newFile,number);
//		//pages.add(p.newFile);
	}
	
	
	

}
